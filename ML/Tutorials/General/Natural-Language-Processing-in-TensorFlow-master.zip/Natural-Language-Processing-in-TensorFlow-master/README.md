# Natural-Language-Processing-in-TensorFlow
Notebook for NLP in TensorFlow course offered by Coursera
